#ifndef TONEGEN_H
#define TONEGEN_H

void dsp_init();
void dsp_output(char code, int len);
void dsp_dial(char *number, int tonelen, int gaplen);

#endif /* TONEGEN_H */
