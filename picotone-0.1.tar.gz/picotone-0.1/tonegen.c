#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <linux/soundcard.h>

#include "dialpad.h"
#include "tonegen.h"

#define DSP_FILE "/dev/dsp"

static int sample_freq = 8000;
static signed char *sin_lut = NULL;
static int dsp_fd;
static int volume = 127;
static int time1=0, time2=0;

static void generate_lut()
{
	int i;

	sin_lut = malloc(sample_freq);

	for (i=0; i<sample_freq; ++i) 
		sin_lut[i] = (volume * cos((i * 2 * M_PI) / sample_freq)) / 2;
}

static void generate_tone(unsigned char *buf, int len, int f1, int f2)
{
	int i;

	for (i=0; i<len; ++i) {
		buf[i] = 128 + sin_lut[time1] + sin_lut[time2];
		time1 = (time1 + f1) % sample_freq;
		time2 = (time2 + f2) % sample_freq;
	}
}

void dsp_init()
{

	int dma_buffer_size = 0x00020007, audio = -1;

	generate_lut();

	dsp_fd = open(DSP_FILE, O_SYNC|O_WRONLY);

	if (dsp_fd < 0) {
		fprintf(stderr, "dsp_init: cant open %s\n", DSP_FILE);
		exit(-1);
	}

	ioctl(dsp_fd, SNDCTL_DSP_SETFRAGMENT, &dma_buffer_size);

	printf("DSP initialised: %i\n", dsp_fd);
}

static inline int char_to_tone(char c)
{
	if (isdigit(c))
		return c - '0';
	else if (c == '*')
		return 10;
	else if (c == '#')
		return 11;
	else if (isspace(c))
		return 12;
	else
		return -1;
}

void dsp_dial(char *number, int tonems, int gapms)
{
	int tonelen = (tonems * sample_freq) / 1000;
	int gaplen = (gapms * sample_freq) / 1000;
	char *buf;

	buf = malloc(tonelen > gaplen ? tonelen : gaplen);

	for (; *number; ++number) {
		int tone, i;

		tone = char_to_tone(*number);

		if (tone < 0)
			continue;
		printf("%i\n", tone);

		generate_tone(buf, tonelen, dialpad[tone][0], dialpad[tone][1]);

		for (i=0; i<tonelen; )
			i += write(dsp_fd, buf+i, tonelen-i);

		// clear buffer and send a gap
		
		memset(buf, 128, gaplen);

		for (i=0; i<gaplen; )
			i += write(dsp_fd, buf+i, gaplen-i);
	}
	
	free(buf);
}

#ifdef TEST
int main(int argc, char *argv[])
{
	dsp_init();

	if (argc < 2)
		printf("Usage: %s <number>\n", argv[0]);
	else
		dsp_dial(argv[1], 900, 300);
}
#endif

