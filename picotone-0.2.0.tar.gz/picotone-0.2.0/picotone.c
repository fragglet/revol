/* $Id: $
 *
 * picotone: A small tone dialer program for picogui
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <sys/time.h>
#include <picogui.h>

#include "tonegen.h"

/* speed dial dialog box */

static pghandle speed_window;
static pghandle speed_dialbox;

static void speed_close(struct pgEvent *evt)
{
	pgDelete(speed_window);
}

static void speed_do_dial(struct pgEvent *evt)
{
	char *number = pgGetString(pgGetWidget(speed_dialbox, PG_WP_TEXT));
	dsp_dial(number, 100, 50);
}

static void speed_dial()
{
	pghandle window, box, box2;

	speed_window = pgNewPopup(150, 0);

	box = pgNewWidget(PG_WIDGET_BOX, 0, 0);

	/* first box with number and label */

	box2 = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	speed_dialbox = pgNewWidget(PG_WIDGET_FIELD, PG_DERIVE_INSIDE, box2);
	pgSetWidget(PGDEFAULT, 
			PG_WP_SIDE, PG_S_LEFT, 
			PG_WP_SIZE, 100, 
			0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box2);
	pgSetWidget(PGDEFAULT, 
			PG_WP_TEXT, pgNewString("Number:"),
			PG_WP_SIDE, PG_S_LEFT,
			0);

	/* 2nd box with buttons */
	
	box2 = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box2);
	pgSetWidget(PGDEFAULT,
			PG_WP_TEXT, pgNewString("Dial"),
			PG_WP_SIDE, PG_S_RIGHT,
			0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, speed_do_dial, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box2);
	pgSetWidget(PGDEFAULT,
			PG_WP_TEXT, pgNewString("Close"),
			PG_WP_SIDE, PG_S_RIGHT,
			0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, speed_close, 0);
}

/* main window */

static int button_press(struct pgEvent *evt)
{
	dsp_dial(evt->extra, 200, 90);
}

static inline void add_button(char *name, pghandle box)
{
	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString(name),
		    PG_WP_SIDE, PG_S_RIGHT,
		    PG_WP_SIZE,pgFraction(1,3),
		    PG_WP_SIZEMODE,PG_SZMODE_CNTFRACT,
		    0);
	pgBind(PGDEFAULT,PG_WE_ACTIVATE,&button_press, name);
}

int main(int argc, char *argv[])
{
	pghandle boxes[4], toolbar;
	int i;

	dsp_init();

	/* fr33 k3v1n m17n1(k!!!1 */
	
	if (argc > 1 && !strcmp(argv[1], "-2600")) {
		dsp_haxor();
		exit(0);
	}

	pgInit(argc, argv);

	pgRegisterApp(PG_APP_NORMAL, "Tone Dialer", 0);

	toolbar = pgNewWidget(PG_WIDGET_TOOLBAR,0,0);

	for (i=0; i<4; ++i) {
		boxes[i] = pgNewWidget(PG_WIDGET_BOX, 0, 0);
		pgSetWidget(PGDEFAULT,
		            PG_WP_SIZE,pgFraction(1,5),
			    PG_WP_SIZEMODE,PG_SZMODE_CNTFRACT,
			    0);
	}

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, toolbar);
	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("Speed Dial"),
		    0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, speed_dial, NULL);
	
	add_button("7", boxes[0]);
	add_button("8", boxes[0]);	
	add_button("9", boxes[0]);
	add_button("4", boxes[1]);	
	add_button("5", boxes[1]);	
	add_button("6", boxes[1]);
	add_button("1", boxes[2]);	
	add_button("2", boxes[2]);	
	add_button("3", boxes[2]);
	add_button("*", boxes[3]);	
	add_button("0", boxes[3]);	
	add_button("#", boxes[3]);

	pgEventLoop();
}

