/* $Id: $
 *
 * picotone: A small tone dialer program for picogui
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef DIALPAD_H
#define DIALPAD_H

static int dialpad[][2] = {
	{941, 1336},			/* 0 */
	{697, 1209},			/* 1 */
	{697, 1336},			/* 2 */
	{697, 1477},			/* 3 */
	{770, 1209},			/* 4 */
	{770, 1336},			/* 5 */
	{770, 1477},			/* 6 */
	{852, 1209},			/* 7 */
	{852, 1336},			/* 8 */
	{852, 1477},			/* 9 */
	{941, 1209},			/* * */
	{941, 1477}, 			/* # */
	{0, 0},				/* silence */
};

#endif /* DIALPAD_H */

