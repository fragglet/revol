#!/bin/sh

echo "Setting hostname.."

cat /etc/hostname > /proc/sys/kernel/hostname

exit 0

