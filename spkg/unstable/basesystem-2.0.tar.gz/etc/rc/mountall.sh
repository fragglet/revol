#!/bin/sh

echo "Mounting local filesystems.."

# must mount proc first
mount proc /proc -t proc

# mount root writable
mount /dev/root / -o remount,rw >/dev/null 2>&1

# give ourselves 256k of ramdisk for /tmp on readonly filesystems.
# we use ram0 since /dev/ram == ram1, and dboostrap uses that for
# other things. We test this with a simple check.
if touch /ro-test >/dev/null 2>&1; then
    rm -f /ro-test # nothing
else

    echo "/ is read only: creating /tmp ramdisk"

    # We need to make sure that whatever is in /tmp, gets copied
    # to the new ramdisk first. We make a 512 ramdisk with 1024 bytes per
    # inode. This should give us ~500 inodes.
    dd if=/dev/zero of=/dev/ram0 bs=1024 count=512
    mke2fs -b 1024 -i 1024 /dev/ram0 >/dev/null 2>&1
    mount /dev/ram0 /mnt -o rw -t ext2
    rm -rf /mnt/lost+found
    cp -a /tmp/. /mnt >/dev/null 2>&1
    rm -f `find /mnt | grep TRANS`
    umount /mnt
    mount /dev/ram0 /tmp -o rw -t ext2
fi

