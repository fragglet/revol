#!/bin/sh

echo "Bringing up loopback interface.."
ifconfig lo 127.0.0.1 up

