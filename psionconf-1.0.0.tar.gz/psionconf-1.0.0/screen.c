/* $Id: $
 *
 * psionconf: configuration program for setting various psion linux settings
 *            under PicoGUI
 *
 * screen.c : Screen settings dialog
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <picogui.h>

#define CONTRAST_FILE "/proc/psionw/contrast"
#define CONTRAST_MAX 58

#define BACKLIGHT_FILE "/proc/psionw/backlight"

extern int psionconf_cat_file(char *file);
extern void psionconf_cat_to_file(char *file, int val);

static int backlight, contrast;

static pghandle dialog;
static pghandle contrast_label;
static pghandle backlight_label;

static int close_handler(struct pgEvent *evt)
{ 
	pgDelete(dialog);
}

static void update()
{
	contrast = psionconf_cat_file(CONTRAST_FILE);

	if (contrast >= 0) {
		pgReplaceTextFmt(contrast_label,
				 "%i%%", (contrast * 100) / CONTRAST_MAX);
	}

	backlight = psionconf_cat_file(BACKLIGHT_FILE);

	if (backlight >= 0) {
		pgReplaceText(backlight_label, backlight ? "On" : "Off");
	}
}

static void contrast_adjust(int i)
{
	FILE *fs;

	contrast += i;

	if (contrast > CONTRAST_MAX)
		contrast = CONTRAST_MAX;
	else if (contrast < 0)
		contrast = 0;

	fs = fopen(CONTRAST_FILE, "w");

	if (!fs) {
		pgMessageDialog("Warning", "Cant open " CONTRAST_FILE,
				PG_MSGBTN_OK);
		return;
	}

	fprintf(fs, "%i\n", contrast);

	fclose(fs);
	
	update();
}

int contrast_minus(struct pgEvent *evt) 
{
	contrast_adjust(-1);
}

int contrast_plus(struct pgEvent *evt) 
{
	contrast_adjust(1);
}

int backlight_toggle(struct pgEvent *evt)
{
	backlight = !backlight;

	psionconf_cat_to_file(BACKLIGHT_FILE, backlight);

	update();
}

int screen_dialog(struct pgEvent *evt) 
{
	pghandle box;

	dialog = pgDialogBox("Screen");

	/* contrast box w/adjustment buttons */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "+");
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &contrast_plus, NULL);

	contrast_label = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "101%");

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "-");
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &contrast_minus, NULL);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Contrast:");

	/* backlight box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Toggle");
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &backlight_toggle, NULL);

	backlight_label = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Backlight:");

	/* close button box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("Close"),
		    PG_WP_SIDE, PG_S_RIGHT,
		    0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &close_handler, NULL);

	update();
}

