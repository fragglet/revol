/* $Id: $
 *
 * psionconf: configuration program for setting various psion linux settings
 *            under PicoGUI
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <picogui.h>

#include "data/power_pnm.h"
#include "data/power_mask_pnm.h"

#include "data/cpu_pnm.h"
#include "data/cpu_mask_pnm.h"

#include "data/screen_pnm.h"

#define DIALOG

extern int power_dialog(struct pgEvent *evt);
extern int cpu_dialog(struct pgEvent *evt);
extern int screen_dialog(struct pgEvent *evt);

int psionconf_cat_file(char *file)
{
	FILE *fs = fopen(file, "r");
	int val = -1;

	if (!fs) {
		char *buf = malloc(strlen(file) + 30);

		sprintf(buf, "Can't open %s", file);

		pgMessageDialog("Warning", buf, PG_MSGBTN_OK);

		free(buf);

		return -1;
	}

	fscanf(fs, "%i\n", &val);

	fclose(fs);

	return val;
}

void psionconf_cat_to_file(char *file, int val)
{
	FILE *fs = fopen(file, "w");

	if (!fs) {
		char *buf = malloc(strlen(file) + 30);

		sprintf(buf, "Can't open %s", file);

		pgMessageDialog("Warning", buf, PG_MSGBTN_OK);

		free(buf);

		return;
	}

	fprintf(fs, "%i\n", val);

	fclose(fs);
}

int main(int argc, char *argv[])
{
	pghandle box;

	pgInit(argc, argv);

#ifdef DIALOG
	pgDialogBox("Psion Config");
#else
	pgRegisterApp(PG_APP_NORMAL, "Psion Config", 0);
#endif

	box = pgNewWidget(PG_WIDGET_BOX, 0, 0);

#ifdef DIALOG
	pgSetWidget(box,
		    PG_WP_SIDE, PG_S_BOTTOM, 
		    0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("Close"),
		    PG_WP_SIDE, PG_S_RIGHT,
		    0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, pgExitEventLoop, 0);
#endif

	/* power button */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, box);

	pgNewWidget(PG_WIDGET_FLATBUTTON, PG_DERIVE_INSIDE, box);

	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("Power"),
		    PG_WP_BITMAP, pgNewBitmap(pgFromMemory(power_pnm, 
							   sizeof(power_pnm))),
		    PG_WP_BITMASK, pgNewBitmap(pgFromMemory(power_mask_pnm, 
							    sizeof(power_mask_pnm))),

		    0);

	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &power_dialog, NULL);

	/* cpu button */

	pgNewWidget(PG_WIDGET_FLATBUTTON, PG_DERIVE_INSIDE, box);

	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("CPU"),
		    PG_WP_BITMAP, pgNewBitmap(pgFromMemory(cpu_pnm, sizeof(cpu_pnm))),
		    PG_WP_BITMASK, pgNewBitmap(pgFromMemory(cpu_mask_pnm, sizeof(cpu_mask_pnm))),
		    0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &cpu_dialog, NULL);

	/* screen button */

	pgNewWidget(PG_WIDGET_FLATBUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT,
		    PG_WP_TEXT, pgNewString("Screen"),
		    PG_WP_BITMAP, pgNewBitmap(pgFromMemory(screen_pnm, sizeof(screen_pnm))),
		    0);
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &screen_dialog, NULL);

	/* run */

	pgEventLoop();
}

