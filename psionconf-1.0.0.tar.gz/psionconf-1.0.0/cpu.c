/* $Id: $
 *
 * psionconf: configuration program for setting various psion linux settings
 *            under PicoGUI
 *
 * cpu.c : CPU dialog box
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <picogui.h>

#define CPUINFO_FILE "/proc/cpuinfo"
#define CPU_FILE "/proc/psionw/cpu"

static pghandle dialog;
static pghandle speed;
static char speedbuf[20];
static pghandle cpuinfo_proc, cpuinfo_features;

static int close_handler(struct pgEvent *evt)
{ 
	pgDelete(dialog);
}

static void update()
{
	FILE *fs = fopen(CPU_FILE, "r");
	strcpy(speedbuf, "");

	if (!fs) {
		pgMessageDialog("Warning", "Cant open " CPU_FILE, 
				PG_MSGBTN_OK);
		return;
	}

	fgets(speedbuf, sizeof(speedbuf) -1, fs);
	speedbuf[sizeof(speedbuf)-1] = '\0';

	fclose(fs);

	if (speedbuf[strlen(speedbuf)-1] == '\n')
		speedbuf[strlen(speedbuf)-1] = '\0';

	pgReplaceTextFmt(speed, "%s MHz", speedbuf);
}

static int speed_handler(struct pgEvent *evt)
{
	if (!strcmp(speedbuf, "36.8"))
		psionconf_cat_to_file(CPU_FILE, 0);
	else
		psionconf_cat_to_file(CPU_FILE, 1);

	update();
}

static void get_cpuinfo()
{
	FILE *fs = fopen(CPUINFO_FILE, "r");
	char buf[128];
	char *value;

	if (!fs) {
		pgMessageDialog("Warning", "Cant open " CPUINFO_FILE,
				PG_MSGBTN_OK);
		return;
	}

	while (!feof(fs)) {
		
		fgets(buf, sizeof(buf)-1, fs);
		buf[sizeof(buf)-1] = '\0';

		if (strlen(buf) > 0 && buf[strlen(buf)-1] == '\n')
			buf[strlen(buf)-1] = '\0';

		for (value=buf; *value && *value != ':'; ++value);

		if (!*value)
			continue;

		*value++ = '\0';

		while (strlen(buf) > 0 && isspace(buf[strlen(buf)-1]))
			buf[strlen(buf)-1] = '\0';
		while (*value && isspace(*value))
			++value;

		if (!strcmp(buf, "Processor")) 
			pgReplaceText(cpuinfo_proc, value);
		else if (!strcmp(buf, "Features"))
			pgReplaceText(cpuinfo_features, value);
	}

	fclose(fs);
}

int cpu_dialog(struct pgEvent *evt)
{
	pghandle box;

	dialog = pgDialogBox("CPU");

	/* processor box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);

	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	cpuinfo_proc = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Processor:");

	/* features box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);

	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	cpuinfo_features = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Features:");

	/* cpu speed box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Toggle");
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &speed_handler, NULL);

	speed = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "CPU Speed:");

	/* close box */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_RIGHT, 0);
	pgReplaceText(PGDEFAULT, "Close");
	pgBind(PGDEFAULT, PG_WE_ACTIVATE, &close_handler, NULL);

	update();
	get_cpuinfo();
}

