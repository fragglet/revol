/* $Id: $
 *
 * psionconf: configuration program for setting various psion linux settings
 *            under PicoGUI
 *
 * power.c : Power settings dialog
 *
 * Copyright(c) 2002 Simon Howard <fraggle@alkali.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>

#include <picogui.h>

extern int psionconf_cat_file(char *file);
extern void psionconf_cat_to_file(char *file, int val);

#define SLEEP_FILE "/proc/psionw/sleep"
#define MAINS_FILE "/proc/psionw/mains"
#define CASE_FILE "/proc/psionw/case"

static pghandle dialog;
static pghandle auto_off;
static pghandle timeout_box;
static pghandle case_label, external;

/* update things that cant be changed: external power, case */

void update_status()
{
	int val = psionconf_cat_file(MAINS_FILE);

	if (val >= 0)
		pgReplaceText(external, val ? "Present            " 
					    : "Not Present");

	val = psionconf_cat_file(CASE_FILE);

	if (val >= 0)
		pgReplaceText(case_label, val ? "Open" : "Closed");
}

/* get current settings */

static void update()
{
	int val;

	val = psionconf_cat_file(SLEEP_FILE);

	if (val >= 0) {
		char buf[128];

		pgSetWidget(auto_off,
			    PG_WP_ON, val != 0,
			    0);

		if (val) {
			sprintf(buf, "%i", val);
		} else {
			strcpy(buf, "");
		}

		pgSetWidget(timeout_box,
			    PG_WP_TEXT, pgNewString(buf),
			    0);
	}

	update_status();
}

static pgidlehandler old_idle_handler = NULL;

void idle_handler()
{
	update_status();
	
	if (old_idle_handler && old_idle_handler != idle_handler)
		old_idle_handler();
}

static int set_val()
{
	FILE *fs;
	int val;

	val = pgGetWidget(auto_off, PG_WP_ON);

	if (val) {
		val = atoi(pgGetString(pgGetWidget(timeout_box, PG_WP_TEXT)));

		if (val < 10) {
			pgMessageDialog("Error", 
			 		"Minimum timeout time is 10 seconds", 
			 		PG_MSGBTN_OK);
			return -1;
		}
	}

	psionconf_cat_to_file(SLEEP_FILE, val);

	return 0;
}

static int close_handler(struct pgEvent *evt)
{ 
	if (!set_val()) {
		pgSetIdle(50, old_idle_handler);
		pgDelete(dialog);
	}
}

int power_dialog(struct pgEvent *evt)
{       
	pghandle box;

	dialog = pgDialogBox("Power");

	/* external power */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	external = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "External Power:");

	/* case open */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	case_label = pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);
	pgReplaceText(PGDEFAULT, "Case:");

	/* auto off checkbox */

	auto_off = pgNewWidget(PG_WIDGET_CHECKBOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);
	pgReplaceText(PGDEFAULT, "Power Auto-Off");

	/* box for timeout label and field */
	
	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);

	timeout_box = pgNewWidget(PG_WIDGET_FIELD, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT,
		    PG_WP_SIDE, PG_S_LEFT,
		    PG_WP_SIZE, 50,
		    0);

	pgNewWidget(PG_WIDGET_LABEL, PG_DERIVE_INSIDE, box);
	pgReplaceText(PGDEFAULT, "Timeout(sec):");
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_LEFT, 0);

	/* box at the bottom for holding close button */

	box = pgNewWidget(PG_WIDGET_BOX, PG_DERIVE_INSIDE, dialog);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_BOTTOM, 0);
	
	pgNewWidget(PG_WIDGET_BUTTON, PG_DERIVE_INSIDE, box);
	pgSetWidget(PGDEFAULT, PG_WP_SIDE, PG_S_RIGHT, 0);
	pgReplaceText(PGDEFAULT, "Close");
        pgBind(PGDEFAULT, PG_WE_ACTIVATE, &close_handler, NULL);

	/* set idle handler */

	old_idle_handler = pgSetIdle(2000, idle_handler);

	update();
}

