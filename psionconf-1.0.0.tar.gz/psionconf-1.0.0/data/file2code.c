#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void codify(char *filename)
{
	char *s = strdup(filename);
	char *output_filename;
	FILE *in, *out;

	in = fopen(filename, "rb");

	if (!in) {
		fprintf(stderr, "codify: cant open %s\n", filename);
		return;
	}

	{
		char *p;
		for (p=s; *p; ++p)
			if (*p == '.')
				*p = '_';
	}

	output_filename = (char *) malloc(strlen(s) + 5);
	sprintf(output_filename, "%s.h", s);

	out = fopen(output_filename, "w");

	if (!out) {
		fprintf(stderr, "codify: cant open %s for writing\n", output_filename);
	} else {
		int l=0;

		fprintf(out, "#ifndef __%s__\n", s);
		fprintf(out, "#define __%s__\n\n", s);

		fprintf(out, "unsigned char %s[] = {\n", s);

		while (!feof(in)) {
			unsigned char c;

			fread(&c, 1, 1, in);

			fprintf(out, "0x%02x, ", c);

			if (l++ > 10) {
				l = 0;
				fprintf(out, "\n");
			}
		}

		fprintf(out, "\n};\n\n");

		fprintf(out, "#endif /* __%s__ */", s);

		fclose(out);
	}

	fclose(in);

	free(s);
	free(output_filename);
}

int main(int argc, char *argv[])
{
	int i;

	for (i=1; i<argc; ++i) {
		codify(argv[i]);
	}

	exit(0);
}

